# NiagaMitra AI — backend & aplikasi siap deploy

Arsitektur: `public/index.html` (aplikasi, desain tetap) + `public/catalog.html` (katalog publik) dilayani oleh `server.js` (Node 18+).
Firebase Auth/Firestore/Storage dipakai langsung dari peramban dan diamankan lewat `firestore.rules` dan `storage.rules`.
Gemini, WhatsApp, dan PDF berjalan di server, sehingga kunci rahasia tidak pernah sampai ke peramban.

## 1. Firebase
1. Buat proyek di console.firebase.google.com. Aktifkan **Authentication → Email/Password**, **Firestore**, dan **Storage**.
2. Project settings → Your apps → tambah **Web app**, lalu salin config ke `public/firebase-config.js`.
3. Tempel isi `firestore.rules` dan `storage.rules` pada tab Rules masing-masing, lalu klik Publish.
4. Project settings → Service accounts → **Generate new private key**. Isi JSON-nya jadikan satu baris pada `FIREBASE_SERVICE_ACCOUNT` di `.env`.
5. Authentication → Settings → Authorized domains: tambahkan domain deploy Anda.

## 2. Gemini
Buat API key di aistudio.google.com, isi `GEMINI_API_KEY`. Nama model ada di `GEMINI_MODEL`; cek daftar model yang tersedia untuk kunci Anda (`GET https://generativelanguage.googleapis.com/v1beta/models`) dan sesuaikan bila perlu.

## 3. WhatsApp Business Cloud API
1. developers.facebook.com → buat app tipe Business → tambahkan produk **WhatsApp**.
2. Isi `WA_APP_SECRET` (App settings → Basic) dan `WA_VERIFY_TOKEN` (string acak buatan Anda) di `.env`.
3. WhatsApp → Configuration → Webhook: Callback URL `https://DOMAIN-ANDA/webhook/whatsapp`, Verify token sama dengan `WA_VERIFY_TOKEN`, lalu subscribe field **messages**. Webhook wajib HTTPS publik.
4. Di aplikasi: Pengaturan → WhatsApp Business → isi Phone Number ID dan access token (gunakan token System User permanen), klik **Simpan & uji**.
Catatan: balasan teks bebas hanya diterima WhatsApp dalam 24 jam sejak pesan terakhir pelanggan; di luar itu perlu message template.

## 4. Menjalankan
```
npm install
cp .env.example .env   # isi nilainya
npm start              # http://localhost:8080
```
Deploy: Cloud Run / Render / Railway / VPS apa pun yang menjalankan `npm start` dengan HTTPS dan variabel `.env`.
Uji PDF tanpa kredensial: `npm run test:pdf`.

## Batasan yang perlu diketahui
- State tiap pengguna disimpan dalam satu dokumen Firestore (batas 1 MB). Foto sudah dipindah ke Storage, tetapi untuk data sangat besar pecah ke subkoleksi.
- PDF hasil AI berupa teks polos; tabel Markdown tidak dirender sebagai tabel. Gambar katalog harus JPEG/PNG.
- Access token WhatsApp disimpan di Firestore pada path `users/{uid}/private/wa` yang ditolak rules untuk klien dan hanya dibaca server. Aktifkan enkripsi tambahan (mis. Cloud KMS) bila perlu.
